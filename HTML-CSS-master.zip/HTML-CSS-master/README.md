#WWW HTML/CSS Workshop

Women Who Code NYC HTML/CSS Workshop

##Class Requirements
Please download these applications before the class
* [Sublime Text](http://www.sublimetext.com): Text editor
* [Google Chrome](http://chrome.google.com): Web browser
* [SourceTree](http://sourcetreeapp.com): Git client
* [Class files](https://github.com/WomenWhoCodeNYC/HTML-CSS/archive/master.zip): The files we will work on during class


##Resources
* [HTML5 Doctor Element Index](http://html5doctor.com/element-index/): A list of all HTML elements and their usage.
* [HTML Color Names](http://www.w3schools.com/html/html_colornames.asp)
* [CSS Zen Garden](http://csszengarden.com)
